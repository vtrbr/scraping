# Donflix API

API Node.js (zero deps) baseada no **donflix.net** + TMDB + VidLink.

- Banner, Top 10, Filmes, Séries
- Plataformas com logo + filtro filme/série
- Pesquisa e calendário de novos episódios
- **Vídeo MP4** direto para ExoPlayer (VidLink + enc-dec)
- Cache 1h (catálogo) · 15min (stream)

## Rodar

```bash
cd donflix-api
npm install
npm start
# http://localhost:7700
```

## Endpoints (path fixo)

### Home / Banner / Top 10
```
GET /v2/home
GET /v2/banner
GET /v2/top10/filmes
GET /v2/top10/series
```

### Catálogo
```
GET /v2/filmes
GET /v2/series
GET /v2/filmes/2
GET /v2/series/top/2
```

### Plataformas
```
GET /v2/providers
GET /v2/netflix/series
GET /v2/netflix/filmes
GET /v2/prime-video/series
GET /v2/disney-plus/filmes
GET /v2/max/series
GET /v2/paramount-plus/series
GET /v2/globoplay/filmes
GET /v2/crunchyroll/series
GET /v2/apple-tv-plus/filmes
GET /v2/mgm-plus/filmes
```

### Pesquisa
```
GET /v2/search/lupin
GET /v2/search?q=lupin&page=1
```

### Calendário (novos episódios)
```
GET /v2/calendar          # próximos 14 dias
GET /v2/calendar/7        # 7 dias
GET /v2/calendar/14/2     # 14 dias, página 2
```

### Detalhe
```
GET /v2/serie/lupin-2021
GET /v2/serie/96677          # por tmdb_id
GET /v2/filme/:slug
```

### Vídeo (MP4 para ExoPlayer)
```
GET /v2/video/serie/96677/1/1
GET /v2/video/filme/550
```

#### Resposta vídeo
```json
{
  "ok": true,
  "stream": "https://bcdn.../file.mp4?sign=...",
  "stream_type": "mp4",
  "quality": "1080",
  "headers": {
    "Referer": "https://vidlink.pro/",
    "Origin": "https://vidlink.pro"
  },
  "qualities": [
    { "quality": "1080", "stream": "...", "stream_type": "mp4" },
    { "quality": "720", "stream": "..." }
  ],
  "captions": [{ "language": "English", "url": "...srt" }],
  "via": "vidlink",
  "idioma": "DUB"
}
```

**ExoPlayer:** use `ProgressiveMediaSource` com a URL `stream` e sete os `headers` no `DefaultHttpDataSource.Factory`.

## Cache
| Dado | TTL |
|------|-----|
| Banner / top10 / lista / providers / search / calendar / detalhe | 1 hora |
| Stream MP4 (sign expira) | 15 min |

## Estrutura
```
donflix-api/
├── package.json
├── README.md
├── server.js
└── lib/
    ├── cache.js
    ├── tmdb.js
    ├── catalog.js
    ├── detail.js
    └── stream.js
```


## Playback (corrigido 2026-11-04)

O CDN `bcdn.hakunaymatata.com` bloqueia:
- `Referer: https://vidlink.pro/` → **429**
- User-Agent de Chrome → **428**

O server agora:
1. Resolve VidLink
2. Testa candidatos (MP4 direto / proxy surge)
3. Devolve `stream` + **`headers: {}`**
4. Campo `playback.forbid_referer: true` e `user_agent: "ExoPlayer"`

**No app (Media3):**
```kotlin
DefaultHttpDataSource.Factory()
  .setUserAgent("ExoPlayer")
  // NÃO setDefaultRequestProperties com Referer
ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(stream))
```


## Vídeo v4 — cadeia de provedores (sem VidLink)

Ordem automática:

1. **pobreflix** — busca por título → MP4 no R2 (sem headers)
2. **comprarebom / clickhost** (via megafilmes embedy) — MP4/HLS (pode precisar `Referer`)

```
GET /v2/video/filme/1423191
GET /v2/video/serie/96677/1/1
```

Resposta:

```json
{
  "ok": true,
  "provider": "pobreflix",
  "stream": "https://....mp4",
  "stream_type": "mp4",
  "headers": {},
  "playback": { "user_agent": "ExoPlayer", "apply_headers": false },
  "tried": [{ "provider": "pobreflix", "ok": true, "ms": 400 }]
}
```

App: se `headers` vier preenchido, aplicar; se `{}`, não mandar Referer/Chrome UA.


## Provedores de vídeo (lógica)

Só fontes que devolvem stream:

| # | Provedor | Site | Usa | Tipo |
|---|----------|------|-----|------|
| 1 | **cineveo** | cineveo.cfd | TMDB id | mp4 |
| 2 | **megafilmes** | megafilmeshd1.com | TMDB id | mp4/hls (clickhost/comprarebom) |
| 3 | **pobreflix** | pobreflixtv.business | título (+ id) | mp4 R2 |

Removidos: vizer (403), redeflix (sem stream direto).

