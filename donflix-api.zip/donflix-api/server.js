/**
 * Donflix API
 *
 * Path fixo — app só concatena.
 * Cache 1h (catálogo) · 15min (stream).
 */

const http = require('http');
const { URL } = require('url');
const {
  banner,
  top10,
  list,
  search,
  calendar,
  providers,
  home
} = require('./lib/catalog');
const { fetchTitle } = require('./lib/detail');
const { resolveVideo } = require('./lib/stream');
const { PROVIDERS, providerBySlug } = require('./lib/tmdb');
const cache = require('./lib/cache');

const PORT = process.env.PORT || 7700;
const STREAMINGS = Object.values(PROVIDERS).map((p) => p.slug);
const TABS = ['series', 'filmes'];

function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(body, null, 2));
}

function intP(v, def) {
  if (v == null || v === '') return def;
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }
  if (req.method !== 'GET') {
    return send(res, 405, { ok: false, erro: 'método não permitido' });
  }

  const u = new URL(req.url, 'http://localhost');
  const p = u.pathname.replace(/\/+$/, '') || '/';
  const parts = p.split('/').filter(Boolean);

  try {
    // Health
    if (p === '/' || p === '/health') {
      return send(res, 200, {
        ok: true,
        nome: 'donflix-api',
        versao: '2.0.0',
        origem: 'https://donflix.net',
        cache: cache.stats(),
        endpoints: {
          home: 'GET /v2/home',
          banner: 'GET /v2/banner',
          top10: 'GET /v2/top10/filmes  |  /v2/top10/series',
          list: 'GET /v2/filmes  |  /v2/series  |  /v2/filmes/2',
          provider: 'GET /v2/netflix/series  |  /v2/prime-video/filmes',
          providers: 'GET /v2/providers',
          search: 'GET /v2/search/lupin  |  /v2/search?q=lupin',
          calendar: 'GET /v2/calendar  |  /v2/calendar/14',
          detalhe: 'GET /v2/serie/:slug  |  /v2/filme/:slug  |  ?tmdb_id=',
          video: 'GET /v2/video/serie/:tmdb_id/:s/:e  |  /v2/video/filme/:tmdb_id'
        },
        streamings: STREAMINGS,
        tabs: TABS
      });
    }

    if (parts[0] !== 'v2') {
      return send(res, 404, { ok: false, erro: 'use /v2/...' });
    }

    // /v2/home
    if (parts[1] === 'home') {
      return send(res, 200, await home());
    }

    // /v2/banner
    if (parts[1] === 'banner') {
      return send(res, 200, await banner());
    }

    // /v2/providers
    if (parts[1] === 'providers') {
      return send(res, 200, await providers());
    }

    // /v2/top10/filmes|series
    if (parts[1] === 'top10') {
      const tipo = parts[2] || 'series';
      return send(res, 200, await top10(tipo));
    }

    // /v2/calendar  |  /v2/calendar/14  |  /v2/calendar/14/2
    if (parts[1] === 'calendar') {
      const days = intP(parts[2], 14);
      const page = intP(parts[3], 1);
      return send(res, 200, await calendar({ days, page }));
    }

    // /v2/search/:query  |  /v2/search?q=
    if (parts[1] === 'search') {
      const q =
        parts[2] != null
          ? decodeURIComponent(parts.slice(2).join('/'))
          : u.searchParams.get('q') || u.searchParams.get('query') || '';
      const page = intP(u.searchParams.get('page'), 1);
      return send(res, 200, await search(q, page));
    }

    // /v2/video/serie/:id/:s/:e  |  /v2/video/filme/:id
    if (parts[1] === 'video') {
      if (parts[2] === 'filme') {
        const id = parts[3];
        if (!id) return send(res, 400, { ok: false, erro: 'use /v2/video/filme/:tmdb_id' });
        try {
          const result = await resolveVideo({
            tipo: 'filme',
            tmdb_id: id
          });
          return send(res, result.ok ? 200 : 502, result);
        } catch (e) {
          return send(res, 502, {
            ok: false,
            erro: String(e.message || e),
            dica: 'VidLink instável. Toque em Tentar novamente em alguns segundos.'
          });
        }
      }
      if (parts[2] === 'serie') {
        const id = parts[3];
        const season = parts[4] || '1';
        const episode = parts[5] || '1';
        if (!id) {
          return send(res, 400, {
            ok: false,
            erro: 'use /v2/video/serie/:tmdb_id/:season/:episode'
          });
        }
        try {
          const result = await resolveVideo({
            tipo: 'serie',
            tmdb_id: id,
            season,
            episode
          });
          return send(res, result.ok ? 200 : 502, result);
        } catch (e) {
          return send(res, 502, {
            ok: false,
            erro: String(e.message || e),
            dica: 'VidLink instável. Toque em Tentar novamente em alguns segundos.'
          });
        }
      }
      return send(res, 400, {
        ok: false,
        erro: 'use /v2/video/serie/:id/:s/:e ou /v2/video/filme/:id'
      });
    }

    // /v2/serie/:slug  |  /v2/filme/:slug
    if (
      (parts[1] === 'serie' || parts[1] === 'filme') &&
      parts[2] &&
      !STREAMINGS.includes(parts[1])
    ) {
      const tipo = parts[1];
      const slug = decodeURIComponent(parts[2]);
      // se for só número → tmdb_id
      if (/^\d+$/.test(slug)) {
        const data = await fetchTitle({
          tipo,
          tmdb_id: parseInt(slug, 10)
        });
        if (data.erro) return send(res, 404, data);
        return send(res, 200, data);
      }
      const data = await fetchTitle({ tipo, slug });
      if (data.erro) return send(res, 404, data);
      return send(res, 200, data);
    }

    // /v2/title?tipo=&tmdb_id=
    if (parts[1] === 'title') {
      const data = await fetchTitle({
        tipo: u.searchParams.get('tipo') || 'serie',
        tmdb_id: u.searchParams.get('tmdb_id')
          ? parseInt(u.searchParams.get('tmdb_id'), 10)
          : null,
        slug: u.searchParams.get('slug')
      });
      if (data.erro) return send(res, 404, data);
      return send(res, 200, data);
    }

    // Catalog path:
    // /v2/series  /v2/filmes  /v2/series/2
    // /v2/netflix/series  /v2/netflix/series/2  /v2/netflix/series/top/2
    {
      let streaming = null;
      let tab = null;
      let sort = 'popular';
      let page = 1;
      let i = 1; // after v2

      if (parts[i] && STREAMINGS.includes(parts[i])) {
        streaming = parts[i++];
      }
      if (parts[i] && TABS.includes(parts[i])) {
        tab = parts[i++];
      }
      if (parts[i] && ['popular', 'top', 'recent'].includes(parts[i])) {
        sort = parts[i++];
      }
      if (parts[i] && /^\d+$/.test(parts[i])) {
        page = parseInt(parts[i++], 10);
      }

      if (tab) {
        const data = await list({
          tipo: tab,
          page,
          sort,
          provider: streaming
        });
        return send(res, 200, data);
      }
    }

    send(res, 404, { ok: false, erro: 'rota não encontrada', dica: 'GET /' });
  } catch (e) {
    send(res, e.status === 404 ? 404 : 502, {
      ok: false,
      erro: e.message || String(e)
    });
  }
});

server.listen(PORT, () => {
  console.log(`donflix-api on :${PORT}`);
  console.log(`  /v2/banner  /v2/top10/series  /v2/netflix/filmes`);
  console.log(`  /v2/search/lupin  /v2/calendar`);
  console.log(`  /v2/video/serie/96677/1/1`);
});
