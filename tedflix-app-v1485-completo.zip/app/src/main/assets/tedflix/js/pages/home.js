import { NOFLIX_ENABLED } from "../config.js";
import { el, limpar } from "../dom.js";
import { hero } from "../components/hero.js";
import { fileira, fileiraTop10 } from "../components/row.js";
import {
  getCarousel,
  getUltimosFilmes,
  buscar,
  parseLink,
  getLancamentos,
  getSeries,
  getGenero,
  getTedtopTelao,
  getTedtopBilheteria,
  getNoflixTopFilmes,
  getNoflixTopSeries,
  getMegacinePainel,
  enriquecerMegacineCapa,
  getMegacinePelicula,
  enriquecerListaTmdb,
  enriquecerComTmdb,
  limparTituloTmdb,
  getTmdbEpisodiosTemporada,
  extrairTmdbId,
  resolverTmdbMeta,
  getNoflixFilmes,
  getNoflixSeries,
  getNoflixSeriesEstreias,
  getNoflixUltimosEps,
  getMegacineSerial,
  getNoflixFilmesGenero,
  getTedv2Home,
  getTedv2PopularMovies,
  getTedv2PopularSeries,
  getTedv2Trending,
  getMegacineGenero,
  getNoflixSeriesGenero,
  getStreamingProviders,
  getGeneroUnificado,
  SrcNew,
} from "../api.js";
import { CATEGORIAS } from "../config.js";
import { GENEROS_CANONICOS, GENEROS_HOME } from "../generos.js";

/**
 * Home estilo Netflix:
 * 1. Hero / destaques
 * 2. Continuar assistindo (destaque)
 * 3. Em cartaz / Bilheteria (TEDTOP)
 * 4. Lançamentos, séries, gêneros (CONTENT)
 */
let _homeContinuarCache = { t: 0, lista: null };
const HOME_CONTINUAR_TTL = 3 * 60 * 1000; // 3 min em memória

export default async function paginaInicio(raiz) {
  const page = el("div", { class: "page home-netflix" });
  const topo = el("div", { class: "hero skel" });
  page.append(topo);
  raiz.append(page);

  // Placeholder do Continuar — nunca bloqueia a pintura do restante da home
  const slotContinuar = el("div", { class: "home-continuar-slot" });
  page.append(slotContinuar);

  const inserirContinuar = (lista) => {
    if (!Array.isArray(lista) || !lista.length || !page.isConnected) return;
    try {
      limpar(slotContinuar);
      slotContinuar.append(
        fileira({
          titulo: "Continuar assistindo",
          carregar: async () => lista,
          limite: 20,
          variante: "continuar",
        }),
      );
    } catch (_) {}
  };

  const agora = Date.now();
  if (_homeContinuarCache.lista && agora - _homeContinuarCache.t < HOME_CONTINUAR_TTL) {
    inserirContinuar(_homeContinuarCache.lista);
  } else {
    // A carga acontece em background; a Home continua navegável durante a sincronização.
    // A Home não espera esta carga: a fileira entra assim que os dados locais/remotos
    // estiverem prontos. Um timeout prematuro escondia a seção quando a sincronização
    // remota levava mais que 3,5 s, mesmo com o restante da Home já utilizável.
    carregarContinuarAssistindo()
      .then((lista) => {
        if (Array.isArray(lista) && lista.length) {
          _homeContinuarCache = { t: Date.now(), lista };
          inserirContinuar(lista);
        }
      })
      .catch(() => {});
  }

  // Top 10 Donflix (substitui NoFlix quando offline)
  page.append(
    fileiraTop10({
      titulo: "Top 10 · Filmes",
      carregar: async () => {
        try {
          const r = await SrcNew.donflixTop10("filmes");
          return r && r.length ? r : null;
        } catch (_) {
          return NOFLIX_ENABLED ? getNoflixTopFilmes(10) : null;
        }
      },
      limite: 10,
    }),
    fileiraTop10({
      titulo: "Top 10 · Séries",
      carregar: async () => {
        try {
          const r = await SrcNew.donflixTop10("series");
          return r && r.length ? r : null;
        } catch (_) {
          return NOFLIX_ENABLED ? getNoflixTopSeries(10) : null;
        }
      },
      limite: 10,
    }),
  );

  // Plataformas / streaming (logos Donflix + Megafilmes)
  const slotProv = el("div", { class: "home-providers-slot" });
  page.append(slotProv);
  (async () => {
    try {
      const provs = await getStreamingProviders();
      if (!provs.length || !slotProv.isConnected) return;
      const wrap = el("div", { class: "fileira providers-row" });
      wrap.append(el("h2", { class: "fileira-titulo", text: "Assistir por streaming" }));
      const sc = el("div", { class: "fileira-scroll providers-scroll" });
      for (const p of provs) {
        const a = el("a", {
          class: "provider-chip",
          href: `#/streaming/${encodeURIComponent(p.slug)}`,
          title: p.nome || p.slug,
        });
        if (p.logo) {
          const img = el("img", { src: p.logo, alt: p.nome || p.slug, loading: "lazy" });
          a.append(img);
        } else {
          a.append(el("span", { text: (p.nome || p.slug || "?").slice(0, 12) }));
        }
        sc.append(a);
      }
      wrap.append(sc);
      slotProv.append(wrap);
    } catch (_) {}
  })();

  // Donflix banner / home quick rows
  page.append(
    fileira({
      titulo: "Destaques",
      carregar: async () => {
        try {
          return (await SrcNew.donflixBanner()) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
  );

  // (removido: Em alta / populares vazios ou instáveis)


  // Lançamentos (MegaCine) — badge DESTACADO nos primeiros
  page.append(
    fileira({
      titulo: "Lançamentos",
      carregar: async () => {
        try {
          const painel = await getMegacinePainel();
          const sec = (painel.secoes || []).find(
            (s) => s.key === "lancamentos" || /lançamento/i.test(String(s.titulo || "")),
          );
          let itens = sec?.itens || [];
          // capa se faltar
          await Promise.race([
            Promise.all(itens.slice(0, 10).map((it) => enriquecerMegacineCapa(it))),
            new Promise((r) => setTimeout(r, 5000)),
          ]);
          itens = itens.map((it, idx) => ({
            ...it,
            badgeExtra: idx < 6 ? "DESTACADO" : it.badgeExtra || null,
          }));
          return itens;
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
  );

  // TEDTOP — Em cartaz / bilheteria (segunda API visível na home)
  page.append(
    fileira({
      titulo: "Em cartaz",
      carregar: async () => { const d = await getTedtopTelao(1); return d.itens || []; },
      limite: 18,
      variante: "tedtop",
    }),
    fileira({
      titulo: "Bilheteria",
      carregar: async () => normalizarTedtop(await getTedtopBilheteria()),
      limite: 18,
      variante: "tedtop",
    }),
  );

  // Helper: mistura listas sem repetir título
  const homeSeenGlobal = new Set();
  const misturar = (...listas) => {
    const seen = new Set();
    const out = [];
    for (const lista of listas) {
      for (const it of lista || []) {
        const k = String(it.titulo || it.name || "")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "");
        if (!k || seen.has(k)) continue;
        seen.add(k);
        out.push(it);
      }
    }
    return out;
  };

  // Catálogo amplo — várias fontes, sem repetir a fileira "Lançamentos"
  page.append(
    fileira({
      titulo: "Filmes pra você",
      verTudo: "#/filmes",
      carregar: async () => {
        const [a, b, c] = await Promise.allSettled([
          NOFLIX_ENABLED ? getNoflixFilmes({ limite: 30 }) : Promise.resolve(null),
          getMegacinePelicula(1),
          getUltimosFilmes(),
        ]);
        return misturar(
          a.status === "fulfilled" ? a.value : [],
          b.status === "fulfilled" ? b.value : [],
          c.status === "fulfilled" ? c.value : [],
        ).slice(0, 28);
      },
      limite: 24,
    }),
    fileira({
      titulo: "Séries pra você",
      verTudo: "#/series",
      carregar: async () => {
        const [a, b, c] = await Promise.allSettled([
          NOFLIX_ENABLED ? getNoflixSeries({ limite: 30 }) : Promise.resolve(null),
          getMegacineSerial(1),
          getSeries(),
        ]);
        return misturar(
          a.status === "fulfilled" ? a.value : [],
          b.status === "fulfilled" ? b.value : [],
          c.status === "fulfilled" ? c.value : [],
        ).slice(0, 28);
      },
      limite: 24,
    }),
    // removido: Estreias de séries / Episódios recentes
    fileira({
      titulo: "Novidades do catálogo",
      verTudo: "#/categoria/lancamentos",
      carregar: async () => {
        try {
          return (await getLancamentos()) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 24,
    }),
  );

  // Gêneros — fontes variadas + anti-repetição GLOBAL entre fileiras
  const generoSeenGlobal = new Set();
  const chaveTitulo = (it) =>
    String(it.titulo || it.name || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "");

  const generosHome = GENEROS_HOME.map((slug) => GENEROS_CANONICOS.find((g) => g.slug === slug)).filter(Boolean);
  generosHome.forEach((c, idx) => {
    page.append(
      fileira({
        titulo: c.label,
        verTudo: `#/categoria/${c.slug}`,
        carregar: async () => {
          try {
            const pool = await getGeneroUnificado(c.slug, 1);
            const fresh = [];
            const reuse = [];
            for (const it of pool || []) {
              const k = chaveTitulo(it);
              if (!k) continue;
              if (generoSeenGlobal.has(k)) reuse.push(it);
              else {
                generoSeenGlobal.add(k);
                fresh.push(it);
              }
              if (fresh.length >= 20) break;
            }
            if (fresh.length < 8) {
              for (const it of reuse) {
                fresh.push(it);
                if (fresh.length >= 16) break;
              }
            }
            return fresh.slice(0, 20);
          } catch (_) {
            return [];
          }
        },
        limite: 20,
      }),
    );
  });

  try {
    // Banner principal: MegaCine /painel hero (com capa via dossier se faltar)
    let destaques = [];
    try {
      const painel = await getMegacinePainel();
      destaques = Array.isArray(painel.hero) ? painel.hero.slice(0, 12) : [];
      // enriquece capa dos primeiros (paralelo, timeout)
      await Promise.race([
        Promise.all(destaques.slice(0, 6).map((it) => enriquecerMegacineCapa(it))),
        new Promise((r) => setTimeout(r, 6000)),
      ]);
    } catch (_) {}
    if (!destaques.length) {
      try { destaques = await getCarousel(); } catch (_) {}
    }
    const h = hero(destaques.length ? destaques : []);
    topo.replaceWith(h);
    page.destruir = () => h.destruir?.();
  } catch (e) {
    topo.classList.remove("skel");
    topo.append(el("div", { class: "center" }, "Não foi possível carregar os destaques."));
  }

  return page;
}

/** Executa tarefas de catálogo com concorrência limitada e mantém a ordem original. */
async function mapComLimite(lista, limite, callback) {
  const entrada = Array.isArray(lista) ? lista : [];
  const saida = new Array(entrada.length);
  let proximo = 0;
  const workers = Array.from({ length: Math.min(Math.max(1, limite), entrada.length) }, async () => {
    while (proximo < entrada.length) {
      const indice = proximo++;
      try {
        saida[indice] = await callback(entrada[indice], indice);
      } catch (_) {
        saida[indice] = null;
      }
    }
  });
  await Promise.all(workers);
  return saida;
}

/** Normaliza itens TEDTOP para o card (slug + imagem https + rota de detalhe). */
function normalizarTedtop(lista) {
  const itens = Array.isArray(lista) ? lista : [];
  return itens
    .map((item) => {
      const slug = String(item.slug || "").trim();
      let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
      if (imagem.startsWith("//")) imagem = `https:${imagem}`;
      const categoria = String(item.categoria || "destaque").trim() || "destaque";
      return {
        ...item,
        titulo: item.titulo || slug,
        slug,
        categoria,
        imagem,
        tipo: item.tipo || "Filme",
        ano: item.ano || "",
        link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
        origem: "tedtop",
        badgeExtra: item.trailer || item.tem_trailer ? "Trailer" : null,
      };
    })
    .filter((i) => i.slug || i.titulo);
}

async function carregarContinuarAssistindo() {
  try {
    if (!window.AndroidPlayer?.getContinueWatching) return [];

    const CACHE_CAPAS = "tedflix:cw-covers:v1";
    const lerCapas = () => {
      try {
        return JSON.parse(localStorage.getItem(CACHE_CAPAS) || "{}") || {};
      } catch (_) {
        return {};
      }
    };
    const salvarCapas = (map) => {
      try {
        const keys = Object.keys(map);
        // limita a 80 capas
        const slim = {};
        keys.slice(0, 80).forEach((k) => {
          slim[k] = map[k];
        });
        localStorage.setItem(CACHE_CAPAS, JSON.stringify(slim));
      } catch (_) {}
    };
    const capas = lerCapas();
    const buscasEmVoo = new Map();
    const buscarUmaVez = (termo) => {
      const query = String(termo || "").trim();
      const chave = query.toLowerCase();
      if (query.length < 2) return Promise.resolve(null);
      if (buscasEmVoo.has(chave)) return buscasEmVoo.get(chave);
      const tarefa = buscar(query).catch(() => null);
      buscasEmVoo.set(chave, tarefa);
      return tarefa;
    };

    const calcProgresso = (item) => {
      const percent = Number(item.percent ?? item.progresso ?? 0);
      if (Number.isFinite(percent) && percent > 0) return Math.min(99, Math.round(percent));

      let pos = Number(item.positionMs ?? 0);
      let dur = Number(item.durationMs ?? 0);
      // fallback: segundos
      if ((!pos || !dur) && (item.positionSeconds || item.durationSeconds)) {
        pos = Number(item.positionSeconds || 0) * 1000;
        dur = Number(item.durationSeconds || 0) * 1000;
      }
      // fallback: tempo "H:MM:SS" ou "MM:SS" ou segundos puros
      if ((!pos || pos <= 0) && item.tempo) {
        const t = String(item.tempo).trim();
        if (/^\d+$/.test(t)) {
          pos = Number(t) * 1000;
        } else if (t.includes(":")) {
          const p = t.split(":").map((x) => Number(x) || 0);
          if (p.length === 3) pos = (p[0] * 3600 + p[1] * 60 + p[2]) * 1000;
          else if (p.length === 2) pos = (p[0] * 60 + p[1]) * 1000;
        }
      }
      if (pos > 0 && dur > 0) return Math.min(99, Math.max(1, Math.round((pos * 100) / dur)));
      // sem duração conhecida: mostra barra mínima se já assistiu algo
      if (pos >= 10_000) return 5;
      return 0;
    };

    const lerSnapshot = () => {
      try {
        const valor = JSON.parse(window.AndroidPlayer.getContinueWatching() || "[]");
        return Array.isArray(valor) ? valor : [];
      } catch (_) {
        return [];
      }
    };

    const localSnapshot = lerSnapshot();
    let itens = localSnapshot;
    if (window.AndroidPlayer.refreshContinueWatching) {
      await new Promise((resolve) => {
        let finalizado = false;
        let timer = 0;
        const concluir = () => {
          if (finalizado) return;
          finalizado = true;
          if (timer) clearTimeout(timer);
          window.__tedflixHistoryReady = null;
          resolve();
        };
        window.__tedflixHistoryReady = concluir;
        try {
          window.AndroidPlayer.refreshContinueWatching();
        } catch (_) {
          concluir();
        }
        // Havendo cache local, não faz a Home esperar várias consultas remotas de progresso.
        // Sem cache, concede uma janela maior para tentar recuperar o histórico da conta.
        timer = setTimeout(concluir, localSnapshot.length ? 900 : 3500);
      });
      const remotoMesclado = lerSnapshot();
      if (remotoMesclado.length) itens = remotoMesclado;
    }

    if (!itens.length) return [];

    const humanizarSlug = (s) =>
      String(s || "")
        .replace(/[-_]+/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase())
        .trim();

    const extrairEpMeta = (item) => {
      let temporada = Number(item.temporada || 0) || 0;
      let episodio = Number(item.episodio || 0) || 0;
      const titulo = String(item.titulo || "");
      const slug = String(item.slug || "");
      const epLabelReady = String(item.epLabel || "").trim();

      const tryPatterns = (src) => {
        const patterns = [
          /s(\d{1,2})\s*e(\d{1,3})/i,
          /t(\d{1,2})\s*e(\d{1,3})/i,
          /(\d{1,2})[x×](\d{1,3})/,
        ];
        for (const p of patterns) {
          const m = src.match(p);
          if (m) return { t: Number(m[1]) || 0, e: Number(m[2]) || 0 };
        }
        return null;
      };

      if (!temporada || !episodio) {
        const hit = tryPatterns(titulo) || tryPatterns(slug);
        if (hit) {
          if (!temporada) temporada = hit.t;
          if (!episodio) episodio = hit.e;
        }
      }
      if (!episodio) {
        const m = titulo.match(/^(\d{1,3})\.\s+\S/);
        if (m) episodio = Number(m[1]) || 0;
      }

      let epLabel = epLabelReady;
      if (!epLabel) {
        if (temporada > 0 && episodio > 0) epLabel = `S${temporada}E${episodio}`;
        else if (episodio > 0) epLabel = `E${episodio}`;
      }

      const isEpisode =
        item.isEpisode === true ||
        /epis/i.test(String(item.tipo || "")) ||
        Boolean(item.serieSlug || item.serieCategoria) ||
        episodio > 0;

      // Nome limpo do episódio (sem "4. ")
      let epNome = titulo.replace(/^\d{1,3}\.\s+/, "").trim();
      // Título da série
      let serieTitulo =
        String(item.serieTitulo || "").trim() ||
        (item.serieSlug ? humanizarSlug(item.serieSlug) : "");

      return { temporada, episodio, epLabel, isEpisode, epNome, serieTitulo };
    };

    const itensElegiveis = itens
      .filter((item) => item && (item.categoria || item.slug || item.titulo || item.filmeId))
      .slice(0, 20);
    // Alguns registros antigos não têm rota/slug e precisam de busca de resolução.
    // Quatro workers evitam disparar até vinte pesquisas ao mesmo tempo.
    const montados = await mapComLimite(itensElegiveis, 4, async (item) => {
          let categoria = String(item.categoria || "").trim();
          let slug = String(item.slug || "").trim();
          let detalhe = null;
          const partesOriginais = parseLink(item.link_assistir || item.link_detalhe || "");
          categoria = categoria || partesOriginais.categoria;
          slug = slug || partesOriginais.slug;
          const cacheKey = `${categoria}:${slug || item.filmeId || item.titulo || ""}`.toLowerCase();
          const meta = extrairEpMeta(item);

          if ((!categoria || !slug) && (item.titulo || item.filmeId)) {
            try {
              const busca = await buscarUmaVez(item.titulo || item.filmeId);
              const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
              const tituloBusca = String(item.titulo || "").trim().toLowerCase();
              const id = String(item.filmeId || "").trim();
              const encontrado =
                resultados.find((candidato) => {
                  const candidatoId = String(
                    candidato.filmeId || candidato.id || candidato._id || "",
                  ).trim();
                  return (
                    (id && candidatoId === id) ||
                    (tituloBusca &&
                      String(candidato.titulo || "").trim().toLowerCase() === tituloBusca)
                  );
                }) || resultados[0];
              if (encontrado) {
                const partes = parseLink(encontrado.link_assistir);
                categoria = categoria || encontrado.categoria || partes.categoria;
                slug = slug || encontrado.slug || partes.slug;
                detalhe = encontrado;
              }
            } catch (_) {}
          }

          const progresso = calcProgresso(item);
          const tipoOrigem = String(item.tipo || detalhe?.tipo || item.contentType || item.categoria || "");
          const tipoRaw = tipoOrigem || "Filme";
          const isEp = meta.isEpisode || /epis/i.test(tipoOrigem);
          const tipoEnriquecimento = isEp || /s[eé]rie|series|tv/i.test(tipoOrigem)
            ? "serie"
            : /filme|movie/i.test(tipoOrigem)
              ? "filme"
              : null;

          let titulo = item.titulo || detalhe?.titulo || slug || "Continuar";
          // Card de série: nome da série em destaque; episódio no meta
          if (isEp) {
            titulo =
              meta.serieTitulo ||
              (item.serieSlug ? humanizarSlug(item.serieSlug) : "") ||
              meta.epNome ||
              titulo;
          }

          let imagem =
            item.thumb || item.imagem || detalhe?.imagem || detalhe?.thumb || capas[cacheKey] || "";
          if (imagem && imagem.startsWith("//")) imagem = "https:" + imagem;
          // Não dispara uma segunda busca por capa: o enriquecimento tipado abaixo
          // trata apenas os itens sem imagem, evitando consultas repetidas por cartão.
          if (imagem && cacheKey) capas[cacheKey] = imagem;

          const serieCategoria = String(item.serieCategoria || "").trim();
          const serieSlug = String(item.serieSlug || "").trim();

          // Link: sempre tela de informações (nunca player direto)
          let link_assistir;
          if (isEp && String(categoria).toLowerCase() === "noflix") {
            const m = String(slug || "").match(/^serie-(\d+)-(\d+)-(\d+)(?:-(dub|leg))?/i);
            if (m) {
              link_assistir = `#/episodio/noflix/${m[1]}/${m[2]}/${m[3]}?audio=${m[4] || "dub"}`;
            } else if (meta.temporada && meta.episodio) {
              const id = String(item.filmeId || "").split("-")[0] || slug;
              link_assistir = `#/episodio/noflix/${encodeURIComponent(id)}/${meta.temporada}/${meta.episodio}?audio=dub`;
            } else {
              link_assistir = `#/noflix/serie/${encodeURIComponent(item.filmeId || slug)}`;
            }
          } else if (isEp && categoria && slug) {
            const q = new URLSearchParams({
              t: String(meta.temporada || 1),
              e: String(meta.episodio || 1),
              serieCategoria: serieCategoria || categoria,
              serieSlug: serieSlug || "",
              filmeId: String(item.filmeId || slug),
              thumb: imagem || "",
              titulo: titulo || "",
            });
            link_assistir = `#/episodio/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
          } else if (categoria && slug) {
            const cat = String(categoria).toLowerCase();
            const isSerie = /s[eé]rie|series|tv/i.test(tipoOrigem) || /serie|s[eé]rie|tv/i.test(String(item.tipo || ""));
            const tmdbLike =
              /^\d+$/.test(String(slug)) ||
              /^(filme|serie)-\d+/.test(String(slug)) ||
              /^\d+$/.test(String(item.filmeId || ""));
            if (cat === "donflix" || (tmdbLike && cat !== "megafilmes" && cat !== "megacine" && cat !== "cine")) {
              const id = String(slug).replace(/^(filme|serie)-/, "").split("-")[0] || item.filmeId;
              link_assistir = `#/donflix/${isSerie ? "serie" : "filme"}/${encodeURIComponent(id)}`;
            } else if (cat === "megafilmes") {
              link_assistir = `#/megafilmes/${isSerie ? "serie" : "filme"}/${encodeURIComponent(slug)}`;
            } else if (cat === "megacine" || cat === "cine") {
              link_assistir = `#/cine/${isSerie ? "serie" : "filme"}/${encodeURIComponent(slug)}`;
            } else {
              link_assistir = `#/titulo/${isSerie ? "serie" : "filme"}/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}`;
            }
          } else if (/^\d+$/.test(String(item.filmeId || ""))) {
            const isSerie = /s[eé]rie|series|tv/i.test(tipoOrigem);
            link_assistir = `#/donflix/${isSerie ? "serie" : "filme"}/${encodeURIComponent(item.filmeId)}`;
          } else {
            link_assistir = item.link_assistir || "#/";
          }
          const link_detalhe = link_assistir;

          // Meta: "S2E4 · 45% assistido" ou só porcentagem
          const partesMeta = [];
          if (isEp && meta.epLabel) partesMeta.push(meta.epLabel);
          if (isEp && meta.epNome && meta.epNome !== titulo) {
            // opcional: nome curto do ep
          }
          if (progresso > 0) partesMeta.push(`${progresso}% assistido`);
          else partesMeta.push("Continuar");

          return {
            titulo,
            imagem,
            categoria: categoria || "filme",
            slug: slug || String(item.filmeId || "").trim(),
            filmeId: item.filmeId || slug,
            tipo: isEp ? "episodio" : tipoRaw,
            _tipoEnriquecimento: tipoEnriquecimento,
            progresso,
            continuarTexto: partesMeta.join(" · "),
            badgeExtra: isEp && meta.epLabel ? meta.epLabel : null,
            link_assistir,
            link_detalhe,
            serieCategoria,
            serieSlug,
            temporada: meta.temporada,
            episodio: meta.episodio,
            epLabel: meta.epLabel,
            isEpisode: isEp,
            updatedAt: Number(item.updatedAt || 0),
          };
        });

    // Dedup forte: série por serieSlug/titulo; filme por slug/filmeId/titulo
    const vistos = new Set();
    const cards = [];
    // ordena por updatedAt desc (mais recente primeiro)
    const ordenados = [...montados].sort(
      (a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0),
    );
    for (const c of ordenados) {
      if (!c || !(c.slug || c.filmeId || c.titulo)) continue;
      const tituloNorm = String(c.titulo || "")
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();
      const keys = [];
      if (c.isEpisode || c.tipo === "episodio") {
        if (c.serieSlug) keys.push(`serie:${c.serieSlug}`);
        if (tituloNorm) keys.push(`serie-titulo:${tituloNorm}`);
        if (c.filmeId) keys.push(`serie-fid:${c.filmeId}`);
      } else {
        if (c.categoria && c.slug) keys.push(`item:${c.categoria}:${c.slug}`);
        if (c.filmeId) keys.push(`fid:${c.filmeId}`);
        if (c.slug) keys.push(`slug:${c.slug}`);
        if (tituloNorm) keys.push(`titulo:${tituloNorm}`);
      }
      if (!keys.length) keys.push(`raw:${c.slug || c.filmeId || tituloNorm}`);
      if (keys.some((k) => vistos.has(k.toLowerCase()))) continue;
      keys.forEach((k) => vistos.add(k.toLowerCase()));
      cards.push(c);
    }

    // Limpa títulos e enriquece capas (com timeout — nunca trava a home)
    for (const c of cards) {
      if (c.titulo) {
        const limpo = limparTituloTmdb(c.titulo, c.serieSlug || c.slug);
        if (limpo && limpo !== c.titulo) c.titulo = limpo;
      }
      // Agrupa visualmente: "Nome da série · S2E4" (um card por série)
      if (c.isEpisode || c.tipo === "episodio" || Number(c.temporada) > 0) {
        const epLabel =
          c.epLabel ||
          (Number(c.temporada) > 0 && Number(c.episodio) > 0
            ? `S${c.temporada}E${c.episodio}`
            : "");
        // Remove sufixo T1E5 / S1E5 do título se existir
        let nome = String(c.titulo || "")
          .replace(/\s*[Tt]\s*\d+\s*[Ee]\s*\d+.*$/u, "")
          .replace(/\s*[Ss]\s*\d+\s*[Ee]\s*\d+.*$/u, "")
          .replace(/\s*[-–—:]\s*$/u, "")
          .trim();
        if (epLabel && nome) {
          c.titulo = `${nome} · ${epLabel}`;
          c.badgeExtra = epLabel;
          c.continuarTexto = c.progresso
            ? `${c.progresso}% · ${epLabel}`
            : epLabel;
        }
        c.tipo = "serie";
        c.isEpisode = true;
      }
    }

    const withTimeout = (p, ms) =>
      Promise.race([
        p,
        new Promise((resolve) => setTimeout(() => resolve(null), ms)),
      ]);

    try {
      const filmesParaEnriquecer = cards.filter((item) => item._tipoEnriquecimento === "filme");
      const seriesParaEnriquecer = cards.filter((item) => item._tipoEnriquecimento === "serie");
      // Mantém no máximo quatro consultas de metadados simultâneas; não cria dois
      // lotes independentes de quatro workers para a mesma fileira.
      const tarefaMetadados = (async () => {
        if (filmesParaEnriquecer.length) await enriquecerListaTmdb(filmesParaEnriquecer, "filme");
        if (seriesParaEnriquecer.length) await enriquecerListaTmdb(seriesParaEnriquecer, "serie");
      })();
      await withTimeout(tarefaMetadados, 4500);
    } catch (_) {}
    cards.forEach((item) => { delete item._tipoEnriquecimento; });

    // Capa específica de episódio é um refinamento opcional: consulta no máximo seis
    // itens, em grupos de três, e nunca bloqueia a Home acima desse limite.
    try {
      const semCapa = cards.filter(
        (c) =>
          c &&
          !String(c.imagem || "").trim() &&
          (c.isEpisode || c.tipo === "episodio" || (Number(c.temporada) > 0 && Number(c.episodio) > 0)),
      ).slice(0, 6);
      await mapComLimite(semCapa, 3, async (c) => {
        let sid = extrairTmdbId(c);
        if (!sid) {
          const meta = await withTimeout(
            resolverTmdbMeta(
              { titulo: c.titulo, slug: c.serieSlug || c.slug, serieSlug: c.serieSlug },
              "serie",
            ),
            3500,
          );
          sid = meta?.tmdb_id || 0;
          if (sid) {
            c.tmdb_id = sid;
            c.idtmdb = sid;
          }
        }
        if (!sid) return;
        const temp = Number(c.temporada) || 1;
        const epn = Number(c.episodio) || 0;
        if (!epn) return;
        const eps = await withTimeout(getTmdbEpisodiosTemporada(sid, temp), 3500);
        const hit = (eps || []).find((e) => Number(e.numero) === epn);
        if (hit?.imagem) {
          c.imagem = hit.imagem;
          c.thumb = hit.imagem;
        }
        if (
          hit?.titulo &&
          (/^\d/.test(String(c.titulo || "")) || /epis[oó]dio/i.test(String(c.titulo || "")))
        ) {
          c.titulo = hit.titulo;
        }
      });
    } catch (_) {}

    // Fallback final Continuar: capa da série se o ep ainda estiver sem arte
    for (const c of cards) {
      if (String(c.imagem || "").trim()) continue;
      const serieKey = `${c.serieCategoria || c.categoria || ""}:${c.serieSlug || ""}`.toLowerCase();
      const fromCache =
        (c.serieSlug && capas[serieKey]) ||
        capas[`${c.categoria || ""}:${c.serieSlug || ""}`.toLowerCase()] ||
        "";
      // se enriquecerListaTmdb/resolverTmdbMeta já setou capa no item "série", usa
      if (fromCache) {
        c.imagem = fromCache;
        c.thumb = fromCache;
      }
    }

    for (const c of cards) {
      if (c.imagem && (c.slug || c.filmeId)) {
        const ck = `${c.categoria || ""}:${c.slug || c.filmeId}`.toLowerCase();
        capas[ck] = c.imagem;
      }
    }

    salvarCapas(capas);
    return cards;
  } catch (_) {
    return [];
  }
}
