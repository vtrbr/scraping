/**
 * resolve.js — resolve título/favorito para rota de detalhe ou episódio.
 * Prioridade: Donflix (TMDB) → CONTENT legado.
 */
import * as SrcNew from "./sources-new.js";
import { buscar, ehSerie, parseLink } from "./api.js";

function scoreTitulo(itemTitulo, nome) {
  const t = String(itemTitulo || "").toLowerCase().replace(/[^a-z0-9]+/gi, "");
  const n = String(nome || "").toLowerCase().replace(/[^a-z0-9]+/gi, "");
  if (!t || !n) return 0;
  if (t === n) return 3;
  if (t.includes(n) || n.includes(t)) return 2;
  return 0;
}

export async function resolveTituloParaRota({ titulo, preferSerie = false } = {}) {
  const t = String(titulo || "").trim();
  if (!t) return null;

  try {
    const d = await SrcNew.donflixSearch(t);
    const itens = Array.isArray(d?.itens) ? d.itens : [];
    const ranked = [...itens].sort(
      (a, b) =>
        scoreTitulo(b.nome || b.titulo, t) - scoreTitulo(a.nome || a.titulo, t),
    );
    const series = ranked.filter((i) => /ser/.test(String(i.tipo || "")));
    const filmes = ranked.filter((i) => !/ser/.test(String(i.tipo || "")));
    const hitS = series.find((i) => scoreTitulo(i.nome || i.titulo, t) > 0);
    const hitF = filmes.find((i) => scoreTitulo(i.nome || i.titulo, t) > 0);
    if (preferSerie && hitS?.tmdb_id)
      return `#/donflix/serie/${hitS.tmdb_id}`;
    if (hitF?.tmdb_id && !preferSerie) return `#/donflix/filme/${hitF.tmdb_id}`;
    if (hitS?.tmdb_id) return `#/donflix/serie/${hitS.tmdb_id}`;
    if (hitF?.tmdb_id) return `#/donflix/filme/${hitF.tmdb_id}`;
  } catch (_) {}

  try {
    const busca = await buscar(t);
    const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
    const hit =
      resultados.find((r) => scoreTitulo(r.titulo, t) >= 2) || resultados[0];
    if (hit) {
      const partes = parseLink(hit.link_assistir || hit.link_detalhe || "");
      const cat = hit.categoria || partes.categoria;
      const slug = hit.slug || partes.slug;
      if (cat && slug) {
        const tipo = ehSerie(hit) ? "serie" : "filme";
        if (String(cat).toLowerCase() === "donflix")
          return `#/donflix/${tipo}/${encodeURIComponent(slug)}`;
        if (String(cat).toLowerCase() === "megafilmes")
          return `#/megafilmes/${tipo}/${encodeURIComponent(slug)}`;
        return `#/titulo/${tipo}/${encodeURIComponent(cat)}/${encodeURIComponent(slug)}`;
      }
    }
  } catch (_) {}

  return null;
}

export async function resolveEpisodioPorTitulo({ titulo, temp = 1, ep = 1 } = {}) {
  const t = String(titulo || "").trim();
  if (!t) return null;
  try {
    const d = await SrcNew.donflixSearch(t);
    const itens = Array.isArray(d?.itens) ? d.itens : [];
    const series = itens.filter((i) => /ser/.test(String(i.tipo || "")));
    const hit =
      series.find((i) => scoreTitulo(i.nome || i.titulo, t) > 0) || series[0];
    if (hit?.tmdb_id) {
      return `#/donflix/serie/${hit.tmdb_id}`;
    }
  } catch (_) {}
  return null;
}
