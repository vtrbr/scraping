/** v1 NovelasFlix CONTENT — catálogo + busca + player m3u8 */
export const CONTENT_API_BASE = "https://v1-novelasflix.onrender.com/api";
/** Alias legado */
export const API_BASE = CONTENT_API_BASE;

/** AUTH — login, conta, favoritos, progresso (NÃO MUDAR) */
export const USER_API_BASE = "https://login-148v.onrender.com";

/** v2 Donflix — home, providers, calendar, video mp4 */
export const DONFLIX_API_BASE = "https://v2-donflix.onrender.com";

/** v3 Megafilmes — streaming tabs, video mp4 */
export const MEGAFILMES_API_BASE = "https://v3-megafilmes.onrender.com";

/** v4 Megacine */
export const MEGACINE_API_BASE = "https://v4-megacine.onrender.com";

/** v5 TMDB Ted (só meta; sem play) */
export const TEDV2_API_BASE = "https://v5-tmdb-tedv2.onrender.com";

/** v6 TedTop (conteúdo; NÃO é auth) */
export const TEDTOP_API_BASE = "https://servidores-ted-auth-h42l.onrender.com";

/** TMDB Helper legado (capas) */
export const TMDB_HELPER_BASE = "https://servidor-tmdb.onrender.com";

/** LIVE */
export const LIVE_API_BASE = "https://api.reidoscanais.st";

/** NoFlix desativado */
export const NOFLIX_ENABLED = false;
export const NOFLIX_API_BASE = "https://servidores-ted-apply3.onrender.com";

export const CATEGORIAS = [
  { slug: "acao", label: "Ação" },
  { slug: "animacao", label: "Animação" },
  { slug: "aventura", label: "Aventura" },
  { slug: "comedia", label: "Comédia" },
  { slug: "drama", label: "Drama" },
    { slug: "ficcao-cientifica", label: "Ficção Científica" },
  { slug: "romance", label: "Romance" },
  { slug: "suspense", label: "Suspense" },
  { slug: "terror", label: "Terror" },
];

export const NAV = [
  { href: "#/", label: "Início", icon: "home" },
  { href: "#/series", label: "Séries", icon: "tv" },
  { href: "#/filmes", label: "Filmes", icon: "film" },
  { href: "#/categorias", label: "Categorias", icon: "grid" },
  { href: "#/agenda", label: "Agenda", icon: "calendar" },
];
