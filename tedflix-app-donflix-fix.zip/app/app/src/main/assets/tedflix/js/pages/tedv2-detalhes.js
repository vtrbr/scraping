import { el, limpar } from "../dom.js";
import { getTedv2Movie, getTedv2Series } from "../api.js";
import { lerFavorito, toggleFavorito } from "../playback.js";

/**
 * Tela legada de detalhes TED v2. O serviço v5 é TMDB/metadados somente:
 * esta página não lista fontes de vídeo e não inicia o player.
 */

function metaLinha(parts) {
  return parts.filter(Boolean).join(" · ");
}

function blocoGeneros(genres) {
  const list = Array.isArray(genres) ? genres : [];
  if (!list.length) return null;
  const wrap = el("div", { class: "tedv2-tags" });
  list.forEach((g) => {
    const nome = typeof g === "string" ? g : g?.name || "";
    if (nome) wrap.append(el("span", { class: "tedv2-tag" }, nome));
  });
  return wrap.childNodes.length ? wrap : null;
}

function blocoElenco(cast) {
  const list = Array.isArray(cast) ? cast : [];
  if (!list.length) return null;
  const section = el("div", { class: "tedv2-cast-section" });
  section.append(el("h2", { class: "tedv2-section-title" }, "Elenco"));
  const rail = el("div", { class: "tedv2-cast-rail" });
  list.slice(0, 14).forEach((c) => {
    const card = el("div", { class: "tedv2-cast-card" });
    if (c.profile) {
      card.append(el("img", {
        class: "tedv2-cast-photo",
        src: c.profile,
        alt: c.name || "",
        loading: "lazy",
        decoding: "async",
      }));
    } else {
      card.append(el("div", { class: "tedv2-cast-photo tedv2-cast-photo--empty" }));
    }
    card.append(el("p", { class: "tedv2-cast-name" }, c.name || "—"));
    if (c.character) card.append(el("p", { class: "tedv2-cast-role" }, c.character));
    rail.append(card);
  });
  section.append(rail);
  return section;
}

function criarHero(page, capa, titulo) {
  const hero = el("div", { class: "detail-hero" });
  if (capa) hero.append(el("img", {
    src: capa,
    alt: titulo,
    class: "detail-hero-img",
    decoding: "async",
    loading: "eager",
  }));
  hero.append(el("div", { class: "veil" }));
  page.append(hero);
}

function criarBotaoFavorito({ info, dados, tmdbId, tipo, titulo, capa }) {
  const filmeId = `tedv2-${dados.tmdb || tmdbId}`;
  let favorito = lerFavorito(filmeId, String(dados.tmdb || tmdbId), "tedv2");
  const btn = el("button", { type: "button", class: "btn ghost" }, favorito ? "♥ Na lista" : "♡ Favorito");
  btn.addEventListener("click", () => {
    favorito = toggleFavorito({
      filmeId,
      slug: String(dados.tmdb || tmdbId),
      categoria: "tedv2",
      titulo,
      thumb: capa,
      tipo,
    });
    btn.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
  });
  info.append(el("div", { class: "detail-actions tedv2-actions" }, [btn]));
}

async function carregarDetalhe(raiz, tmdbId, tipo) {
  const page = el("div", { class: "page page-detail page-tedv2" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados = null;
  try {
    dados = tipo === "serie" ? await getTedv2Series(tmdbId) : await getTedv2Movie(tmdbId);
  } catch (_) {
    dados = null;
  }
  limpar(page);
  if (!dados) {
    page.append(el("p", { class: "center pad" }, "Não foi possível carregar os metadados deste título."));
    return page;
  }

  const titulo = dados.titulo || dados.title || (tipo === "serie" ? "Série" : "Filme");
  const capa = dados.capa || dados.poster || dados.backdrop || "";
  criarHero(page, capa, titulo);

  const info = el("div", { class: "detail-info pad" });
  info.append(el("h1", {}, titulo));
  info.append(el("p", { class: "sub tedv2-meta" }, metaLinha([
    dados.vote_average != null ? `★ ${Number(dados.vote_average).toFixed(1)}` : "",
    dados.year || dados.ano || "",
    tipo === "serie" ? "Série" : "Filme",
    tipo === "filme" && dados.runtime ? `${dados.runtime} min` : "",
    tipo === "serie" && dados.number_of_seasons ? `${dados.number_of_seasons} temporadas` : "",
    tipo === "serie" && dados.number_of_episodes ? `${dados.number_of_episodes} episódios` : "",
  ])));

  criarBotaoFavorito({ info, dados, tmdbId, tipo, titulo, capa });

  if (dados.sinopse || dados.overview) {
    info.append(el("p", { class: "detail-sinopse" }, dados.sinopse || dados.overview));
  }
  const genres = blocoGeneros(dados.genres || dados.generos);
  if (genres) info.append(genres);
  const cast = blocoElenco(dados.cast || []);
  if (cast) info.append(cast);

  if (tipo === "serie") {
    info.append(el("p", { class: "sub tedv2-metadata-note" },
      "Informações fornecidas pelo TMDB. Esta fonte não possui links de vídeo nem episódios reproduzíveis."));
  }
  page.append(info);
  return page;
}

export async function paginaTedv2Filme(raiz, tmdbId) {
  return carregarDetalhe(raiz, tmdbId, "filme");
}

export async function paginaTedv2Serie(raiz, tmdbId) {
  return carregarDetalhe(raiz, tmdbId, "serie");
}

export default async function paginaTedv2Detalhe(raiz, { tipo, id }) {
  if (tipo === "serie" || tipo === "series") return paginaTedv2Serie(raiz, id);
  return paginaTedv2Filme(raiz, id);
}
