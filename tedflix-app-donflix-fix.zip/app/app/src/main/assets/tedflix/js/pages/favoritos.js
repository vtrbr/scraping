import { el, limpar } from "../dom.js";
import { cardTitulo, skeletonCard } from "../components/card.js";
import { buscar, parseLink, buscarNoflix } from "../api.js";
import { mapaProgresso, percentFromItem } from "../playback.js";

/** Detecta episódio NoFlix a partir do filmeId (ex: 58566-t1e77 ou serie-58566-1-77-dub). */
function parseNoflixEpId(filmeId) {
  const s = String(filmeId || "").trim();
  let m = s.match(/^(\d+)-t(\d+)e(\d+)$/i);
  if (m) return { idtmdb: m[1], temp: m[2], ep: m[3] };
  m = s.match(/^serie-(\d+)-(\d+)-(\d+)(?:-(dub|leg))?$/i);
  if (m) return { idtmdb: m[1], temp: m[2], ep: m[3], audio: m[4] || "dub" };
  return null;
}

/** Extrai T1E77 / S1E77 do título. */
function parseEpDoTitulo(titulo) {
  const t = String(titulo || "");
  let m = t.match(/t\s*(\d+)\s*e\s*(\d+)/i);
  if (m) return { temp: m[1], ep: m[2] };
  m = t.match(/s\s*(\d+)\s*e\s*(\d+)/i);
  if (m) return { temp: m[1], ep: m[2] };
  return null;
}

/** Nome da série sem o sufixo T1E5 / S1E5. */
function nomeSerieDoTitulo(titulo) {
  return String(titulo || "")
    .replace(/\s*[Tt]\s*\d+\s*[Ee]\s*\d+.*$/u, "")
    .replace(/\s*[Ss]\s*\d+\s*[Ee]\s*\d+.*$/u, "")
    .replace(/\s*[-–—:]\s*$/u, "")
    .trim();
}

/**
 * Monta rota de detalhe/info. Episódios sempre vão para tela de info.
 * Nunca retorna rota que só mostra "não localizado" sem tentar resolve.
 */
function rotaFavorito(item) {
  const filmeId = String(item.filmeId || item.id || "").trim();
  const titulo = String(item.titulo || "").trim();
  const tipo = String(item.tipo || item.contentType || "").toLowerCase();
  let categoria = String(item.categoria || "").trim();
  let slug = String(item.slug || "").trim();
  const imagem = String(item.thumb || item.imagem || "").trim();
  const epTitulo = parseEpDoTitulo(titulo);
  const nf = parseNoflixEpId(filmeId) || parseNoflixEpId(slug);
  const serieNome = nomeSerieDoTitulo(titulo);

  // 1) Episódio NoFlix por id estruturado
  if (nf) {
    return `#/episodio/noflix/${nf.idtmdb}/${nf.temp}/${nf.ep}?audio=${nf.audio || "dub"}`;
  }

  // 2) id numérico + T/E no título
  if (/^\d+$/.test(filmeId) && epTitulo) {
    return `#/episodio/noflix/${filmeId}/${epTitulo.temp}/${epTitulo.ep}?audio=dub`;
  }

  // 3) Tem T/E no título mas sem id → resolve assíncrono (NoFlix + CONTENT)
  if (epTitulo && serieNome) {
    const q = new URLSearchParams({
      titulo: serieNome,
      t: String(item.temporada || epTitulo.temp || 1),
      e: String(item.episodio || epTitulo.ep || 1),
      thumb: imagem,
      filmeId,
    });
    return `#/episodio/resolve?${q}`;
  }

  // 4) tipo episodio + categoria/slug CONTENT
  if ((tipo === "episodio" || tipo === "episode") && categoria && slug) {
    const q = new URLSearchParams({
      t: String(item.temporada || 1),
      e: String(item.episodio || 1),
      serieCategoria: item.serieCategoria || categoria,
      serieSlug: item.serieSlug || "",
      filmeId,
      thumb: imagem,
      titulo,
    });
    return `#/episodio/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
  }

  // 4b) MegaCine
  const cine = String(filmeId || slug || "").match(/^cine-(filme|serie)-(.+)$/i);
  if (cine) {
    return cine[1].toLowerCase() === "serie"
      ? `#/cine/serie/${encodeURIComponent(cine[2])}`
      : `#/cine/filme/${encodeURIComponent(cine[2])}`;
  }
  if ((categoria === "megacine" || categoria === "cine") && slug) {
    const isSerie = tipo.includes("serie") || tipo.includes("séri");
    return isSerie ? `#/cine/serie/${encodeURIComponent(slug)}` : `#/cine/filme/${encodeURIComponent(slug)}`;
  }

  // 5) NoFlix série/filme por idtmdb
  if (/^\d+$/.test(filmeId)) {
    if (tipo.includes("serie") || tipo.includes("séri") || tipo === "tv") {
      return `#/noflix/serie/${filmeId}`;
    }
    return `#/noflix/filme/${filmeId}`;
  }

  // 6) CONTENT com categoria/slug
  if (categoria && slug) {
    const isSerie = tipo.includes("serie") || tipo.includes("séri") || tipo.includes("tv");
    return `#/titulo/${isSerie ? "serie" : "filme"}/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}`;
  }

  // 7) Fallback: resolve por título (filme ou série)
  if (titulo) {
    const q = new URLSearchParams({ titulo, thumb: imagem, filmeId });
    return `#/favorito/resolve?${q}`;
  }
  return "#/favoritos";
}

export default async function paginaFavoritos(raiz) {
  const page = el("div", { class: "page page-favoritos" });
  page.append(
    el("h1", { class: "page-title pad" }, "Minha lista"),
    el("p", { class: "sub pad", style: "padding-top:0" }, "Títulos que você marcou como favorito"),
  );
  const grid = el("div", { class: "grid pad", style: "margin-top:12px" });
  for (let i = 0; i < 6; i++) grid.append(skeletonCard());
  page.append(grid);
  raiz.append(page);

  try {
    if (!window.AndroidPlayer?.getFavorites) {
      limpar(grid);
      grid.append(el("p", { class: "sub" }, "Favoritos disponíveis apenas no app."));
      return page;
    }
    const raw = JSON.parse(window.AndroidPlayer.getFavorites() || "{}");
    const lista = Array.isArray(raw.favoritos) ? raw.favoritos : Array.isArray(raw) ? raw : [];
    if (!lista.length) {
      limpar(grid);
      grid.append(
        el("div", { class: "empty-state" }, [
          el("p", { class: "sub" }, "Sua lista está vazia."),
          el("a", { class: "btn primary", href: "#/" }, "Explorar catálogo"),
        ]),
      );
      return page;
    }

    const cards = await Promise.all(
      lista.map(async (item) => {
        const titulo = String(item.titulo || "").trim();
        const filmeId = String(item.filmeId || item.id || "").trim();
        let categoria = String(item.categoria || "").trim();
        let slug = String(item.slug || "").trim();
        let imagem = String(item.thumb || item.imagem || "").trim();
        let tipo = String(item.tipo || item.contentType || "").trim() || "Filme";

        const nf = parseNoflixEpId(filmeId) || parseNoflixEpId(slug);
        const epTitulo = parseEpDoTitulo(titulo);
        if (nf || epTitulo) tipo = "episodio";

        // Tenta enriquecer id NoFlix se for episódio só com título (ex: Spider-Noir T1E5)
        if (epTitulo && !nf && !/^\d+$/.test(filmeId)) {
          const serieNome = nomeSerieDoTitulo(titulo);
          if (serieNome) {
            try {
              const res = await buscarNoflix(serieNome, 12);
              // API: series/filmes podem ser contagem (int); a lista real está em resultados
              const lista = Array.isArray(res?.resultados) ? res.resultados : [];
              const series = lista.filter((s) => {
                const tp = String(s.tipo || "").toLowerCase();
                return tp.includes("serie") || tp.includes("séri") || tp === "tv" || s.total_temporadas;
              });
              const nome = serieNome.toLowerCase().replace(/[^a-z0-9]+/gi, "");
              const hit =
                series.find((s) => {
                  const t = String(s.titulo || "").toLowerCase().replace(/[^a-z0-9]+/gi, "");
                  return t === nome || t.includes(nome) || nome.includes(t);
                }) || series[0];
              if (hit?.idtmdb) {
                const id = String(hit.idtmdb);
                const href = `#/episodio/noflix/${id}/${epTitulo.temp}/${epTitulo.ep}?audio=dub`;
                return {
                  titulo,
                  filmeId: `${id}-t${epTitulo.temp}e${epTitulo.ep}`,
                  categoria: "noflix",
                  slug: `serie-${id}-${epTitulo.temp}-${epTitulo.ep}-dub`,
                  imagem: imagem || hit.capa || hit.imagem || "",
                  thumb: imagem || hit.capa || hit.imagem || "",
                  tipo: "episodio",
                  isEpisode: true,
                  link_detalhe: href,
                  link_assistir: href,
                };
              }
            } catch (_) {}
          }
        }

        if ((!categoria || !slug) && !nf && !/^\d+$/.test(filmeId) && titulo) {
          try {
            // 1) CONTENT
            const busca = await buscar(titulo);
            const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
            const nome = titulo.toLowerCase();
            const hit =
              resultados.find((r) => {
                const id = String(r.filmeId || r.id || "").trim();
                const rt = String(r.titulo || "").toLowerCase();
                return (filmeId && id === filmeId) || rt === nome || rt.includes(nome) || nome.includes(rt);
              }) || resultados[0];
            if (hit) {
              const p = parseLink(hit.link_assistir);
              if (!categoria) categoria = hit.categoria || p.categoria || "";
              if (!slug) slug = hit.slug || p.slug || "";
              if (!imagem) imagem = hit.imagem || hit.capa || hit.thumb || "";
              if (!tipo || tipo === "Filme") tipo = hit.tipo || tipo;
            }
          } catch (_) {}
          // 2) NoFlix se ainda sem rota
          if ((!categoria || !slug) && !epTitulo) {
            try {
              const nx = await buscarNoflix(titulo, 12);
              const lista = Array.isArray(nx?.resultados) ? nx.resultados : [];
              const nome = titulo.toLowerCase().replace(/[^a-z0-9]+/gi, "");
              const hit = lista.find((s) => {
                const t = String(s.titulo || "").toLowerCase().replace(/[^a-z0-9]+/gi, "");
                return t === nome || t.includes(nome) || nome.includes(t);
              }) || lista[0];
              if (hit?.idtmdb) {
                const isSerie = /serie|séri/i.test(String(hit.tipo || ""));
                categoria = "noflix";
                slug = String(hit.idtmdb);
                filmeId = String(hit.idtmdb);
                if (!imagem) imagem = hit.capa || hit.imagem || "";
                tipo = isSerie ? "serie" : "filme";
              }
            } catch (_) {}
          }
        }

        const base = {
          titulo,
          filmeId,
          categoria,
          slug,
          imagem,
          thumb: imagem,
          tipo,
          contentType: tipo,
          temporada: item.temporada || epTitulo?.temp,
          episodio: item.episodio || epTitulo?.ep,
          serieCategoria: item.serieCategoria,
          serieSlug: item.serieSlug,
          isEpisode: Boolean(nf || epTitulo || /episodio|episode/i.test(tipo)),
        };
        const href = rotaFavorito(base);
        return {
          ...base,
          link_detalhe: href,
          link_assistir: href,
        };
      }),
    );

    const progressoMap = mapaProgresso();

    cards.forEach((c) => {
      const keys = [
        `${c.categoria || ""}:${c.slug || c.filmeId || ""}`.toLowerCase(),
        String(c.filmeId || "").toLowerCase(),
        String(c.slug || "").toLowerCase(),
        String(c.titulo || "").trim().toLowerCase(),
      ];
      let p = 0;
      for (const k of keys) if (progressoMap[k]) { p = progressoMap[k]; break; }
      if (p > 0) {
        c.progresso = p;
        c.continuarTexto = `${p}% assistido`;
      }
    });

    limpar(grid);
    const frag = document.createDocumentFragment();
    cards.forEach((c) => frag.append(cardTitulo(c, { size: "md", eager: true })));
    grid.append(frag);
  } catch (e) {
    limpar(grid);
    grid.append(el("p", { class: "sub" }, "Não foi possível carregar os favoritos."));
  }

  return page;
}
