import { el, limpar, anoCurto } from "../dom.js";
import * as SrcNew from "../sources-new.js";
import { abrirPlayerNativo } from "../playback.js";
import { enriquecerComTmdb } from "../api.js";
import { lerFavorito } from "../playback.js";
import { montarFicha, montarEpisodiosUI } from "../components/ficha.js";

function pickDetalhe(d) {
  if (!d) return null;
  const tit = d.titulo || {};
  const img = d.imagens || {};
  const textos = d.textos || {};
  const desc = d.descricao || {};
  const metricas = d.metricas || {};
  const ids = d.ids || {};
  const player = d.player || {};
  const classif = d.classificacao || {};
  const gens = classif.generos || d.generos || metricas.generos || [];
  return {
    nome: tit.principal || tit.nome || d.nome || d.titulo || "",
    slug: tit.slug || d.slug || "",
    tipo: String(tit.tipo || d.tipo || "filme").toLowerCase(),
    ano: tit.ano || d.ano || null,
    poster: img.poster || d.url_imagem || d.capa || d.poster || null,
    backdrop: img.backdrop || d.backdrop || img.banner || null,
    overview:
      desc.sinopse ||
      d.overview ||
      d.sinopse ||
      textos.sinopse ||
      textos.descricao ||
      "",
    nota: metricas.nota_tmdb || d.nota_tmdb || d.nota || null,
    generos: Array.isArray(gens) ? gens : [],
    tmdb_id: player.tmdb_id || d.tmdb_id || ids.tmdb || tit.tmdb_id || null,
    video_path: player.video_path || null,
    temporadas: d.temporadas || d.seasons || player.temporadas || [],
    total_temporadas: tit.total_temporadas || player.total_temporadas || null,
    classificacao: classif.indicativa || classif.age || null,
    duracao: metricas.duracao || d.duracao || null,
  };
}

export async function paginaDonflix(raiz, { tipo, id }) {
  return paginaFonte(raiz, { api: "donflix", tipo, id });
}

export async function paginaMegafilmes(raiz, { tipo, id }) {
  return paginaFonte(raiz, { api: "megafilmes", tipo, id });
}

async function paginaFonte(raiz, { api, tipo, id }) {
  document.body.classList.add("ficha-mode");
  const page = el("div", { class: "page page-ficha" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let raw;
  try {
    if (api === "donflix") {
      raw =
        tipo === "serie"
          ? await SrcNew.donflixDetalheSerie(id)
          : await SrcNew.donflixDetalheFilme(id);
    } else {
      raw = await SrcNew.megafilmesDetalhe(tipo, id);
    }
  } catch (e) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Não foi possível carregar este título."));
    return page;
  }

  let d = pickDetalhe(raw);
  if (!d || !d.nome) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título não encontrado."));
    return page;
  }

  try {
    const en = await enriquecerComTmdb(
      {
        titulo: d.nome,
        nome: d.nome,
        ano: d.ano,
        tipo: d.tipo,
        tmdb_id: d.tmdb_id,
        imagem: d.poster,
        sinopse: d.overview,
        nota: d.nota,
        generos: d.generos,
      },
      tipo,
    );
    if (en) {
      d.nome = en.titulo || en.nome || d.nome;
      d.overview = en.sinopse || en.descricao || d.overview;
      d.poster = en.capa || en.poster || en.imagem || d.poster;
      d.backdrop = en.banner || en.backdrop || d.backdrop;
      if (en.nota != null && Number(en.nota) > 0) d.nota = en.nota;
      if (en.generos?.length) d.generos = en.generos;
      if (en.tmdb_id) d.tmdb_id = en.tmdb_id;
      if (en.ano) d.ano = en.ano;
    }
  } catch (_) {}

  const isSerie = /ser/.test(String(d.tipo || tipo));
  const filmeId = String(d.tmdb_id || id);
  let favorito = false;
  try {
    favorito = !!lerFavorito(filmeId, String(id), api);
  } catch (_) {}

  const after = [];
  if (isSerie && Array.isArray(d.temporadas) && d.temporadas.length) {
    after.push(
      montarEpisodiosUI({
        temporadas: d.temporadas.map((t, idx) => ({
          numero: t.numero || t.season_number || idx + 1,
          episodios: (t.episodios || t.episodes || []).map((ep, ei) => ({
            numero: ep.numero || ep.episode_number || ei + 1,
            titulo: ep.nome || ep.name || ep.titulo || "",
            imagem: ep.still || ep.imagem || ep.thumb || d.poster,
            video_path: ep.video_path || null,
            duracao: ep.duracao || ep.runtime || null,
          })),
        })),
        serieCapa: d.poster || "",
        onPlayEp: (ep, temp, num) => play(d, temp, num),
      }),
    );
  }

  function play(dNow, temp, ep) {
    const tmdb = dNow.tmdb_id || (String(id).match(/^\d+$/) ? id : null);
    const isSer = /ser/.test(String(dNow.tipo || tipo));
    if (api === "donflix") {
      const t = temp || 1;
      const e = ep || 1;
      const slugPlay = isSer ? `serie-${tmdb || id}-${t}-${e}` : `filme-${tmdb || id}`;
      abrirPlayerNativo({
        categoria: "donflix",
        slug: slugPlay,
        titulo: dNow.nome,
        tipo: isSer ? "serie" : "filme",
        thumb: dNow.poster || "",
        filmeId: String(tmdb || id),
      });
    } else {
      const mid = raw?.ids?.id || raw?.id || id;
      const t = temp || 1;
      const e = ep || 1;
      const slugPlay = isSer ? `serie-${mid}-${t}-${e}` : `filme-${mid}`;
      abrirPlayerNativo({
        categoria: "megafilmes",
        slug: slugPlay,
        titulo: dNow.nome,
        tipo: isSer ? "serie" : "filme",
        thumb: dNow.poster || "",
        filmeId: String(mid),
      });
    }
  }

  limpar(page);
  page.append(
    montarFicha({
      titulo: d.nome,
      poster: d.poster,
      nota: d.nota,
      ano: anoCurto(d.ano) || d.ano,
      tipoLabel: isSerie ? "Série" : "Filme",
      duracao: !isSerie ? d.duracao : null,
      temps: isSerie ? d.total_temporadas || d.temporadas?.length || null : null,
      classificacao: d.classificacao,
      generos: d.generos,
      sinopse: d.overview,
      favorito,
      playLabel: isSerie ? "Assistir" : "Assistir",
      onPlay: () => play(d),
      onFavorite: () => {
        try {
          const resposta = JSON.parse(
            window.AndroidPlayer?.toggleFavorite?.(
              filmeId,
              d.nome || "Tedflix",
              d.poster || "",
              isSerie ? "series" : "movie",
            ) || "{}",
          );
          if (resposta.success) {
            favorito =
              typeof resposta.favorito === "boolean" ? resposta.favorito : !favorito;
          }
        } catch (_) {}
        return { favorito };
      },
      after,
    }),
  );
  return page;
}

export default paginaDonflix;
