import { el } from "../dom.js";
import { GENEROS_CANONICOS } from "../generos.js";

export { GENEROS_CANONICOS as GENEROS_UNIFICADOS };

function svgIco(name) {
  const paths = {
    trend: '<path d="M3 17l6-6 4 4 7-8"/><path d="M14 7h6v6"/>',
    nav: '<path d="M12 2l3 8 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"/>',
    smile: '<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><path d="M9 9h.01M15 9h.01"/>',
    star: '<path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.5L12 17.8 6.1 20.6l1.2-6.5L2.5 9.5l6.6-.9L12 2.5z"/>',
    alert: '<path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.2-3.2"/>',
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    play: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9l5 3-5 3z"/>',
    pin: '<path d="M12 21s-7-5.5-7-11a7 7 0 1 1 14 0c0 5.5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    film: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
    rocket: '<path d="M5 19c1-4 4-7 9-9 2-3 4-4 6-5-1 2-2 4-5 6-2 5-5 8-9 9z"/><path d="M9 15l-3 3"/>',
    heart: '<path d="M12 20s-7-4.4-7-10a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
    shield: '<path d="M12 3l8 4v5c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V7z"/>',
    book: '<path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 0-2 2V5z"/><path d="M6 3v16"/>',
    music: '<path d="M9 18a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M12 15V5l8-2v10"/><path d="M20 13a3 3 0 1 1-6 0"/>',
    flag: '<path d="M4 21V4"/><path d="M4 4h12l-2 4 2 4H4"/>',
    tv: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 21h8M12 18v3"/>',
  };
  const body = paths[name] || paths.film;
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${body}</svg>`;
}

function hexToRgba(hex, a) {
  const h = String(hex || "#333").replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return `rgba(${r},${g},${b},${a})`;
}

export default function paginaCategorias(raiz) {
  const page = el("div", { class: "page page-categorias" });
  const hero = el("div", { class: "cat-hero" });
  const ico = el("div", { class: "cat-hero-icon" });
  ico.innerHTML = svgIco("film");
  hero.append(
    ico,
    el("div", {}, [
      el("h1", {}, "Categorias"),
      el("p", {}, "Explore filmes e séries por gênero"),
    ]),
  );
  page.append(hero);

  const grid = el("div", { class: "cat-grid-modern" });
  for (const g of GENEROS_CANONICOS) {
    const bg = `linear-gradient(135deg, ${hexToRgba(g.tom, 0.55)} 0%, ${hexToRgba(g.tom, 0.18)} 100%)`;
    const a = el("a", {
      class: "cat-card",
      href: `#/categoria/${encodeURIComponent(g.slug)}`,
      style: `background:${bg};color:#f2f2f5`,
    });
    const iconWrap = el("span", { class: "cat-card-ico" });
    iconWrap.innerHTML = svgIco(g.ico);
    a.append(iconWrap, el("span", { class: "cat-card-label" }, g.label));
    grid.append(a);
  }
  page.append(grid);
  raiz.append(page);
  return page;
}
