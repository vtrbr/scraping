import { el, limpar } from "../dom.js";
import { getAgenda, getMegacineCronograma } from "../api.js";
import * as SrcNew from "../sources-new.js";

function parseEpLabel(label) {
  const s = String(label || "");
  const m = s.match(/T\s*(\d+)\s*E\s*(\d+)/i) || s.match(/S\s*(\d+)\s*E\s*(\d+)/i);
  if (m) return { t: Number(m[1]), e: Number(m[2]) };
  return null;
}

export default async function paginaAgenda(raiz) {
  const page = el("div", { class: "page page-agenda" });
  const corpo = el("div", { class: "agenda-corpo" });
  page.append(el("h1", { class: "page-title" }, "Agenda"), corpo);
  raiz.append(page);
  corpo.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));

  try {
    let dias = [];

    // 1) MegaCine
    try {
      const mc = await getMegacineCronograma();
      if (Array.isArray(mc) && mc.length) dias = dias.concat(mc);
    } catch (_) {}

    // 2) Donflix calendar — sempre abaixo / junto
    try {
      const cal = await SrcNew.donflixCalendar(14, 1);
      const byDay = new Map();
      for (const it of cal.itens || []) {
        const key = String(it.data || cal.meta?.de || "Novos episódios");
        if (!byDay.has(key)) byDay.set(key, { nome: key, data: key, episodios: [] });
        const id = it.slug || it.tmdb_id;
        byDay.get(key).episodios.push({
          titulo: it.titulo || it.nome,
          serie: it.titulo || it.nome,
          episodio: it.episodio || "",
          horario: it.horario || "",
          slug: id,
          tipo: "serie",
          imagem: it.imagem || it.capa || "",
          link_detalhe: id
            ? `#/donflix/serie/${encodeURIComponent(id)}`
            : "",
        });
      }
      for (const d of byDay.values()) {
        if (d.episodios.length) dias.push(d);
      }
    } catch (_) {}

    // 3) legado getAgenda
    if (!dias.length) {
      try {
        const g = await getAgenda();
        if (Array.isArray(g)) dias = g;
      } catch (_) {}
    }

    dias = dias
      .map((dia) => {
        const eps = dia.episodios || dia.itens || [];
        return {
          nome: dia.nome || dia.rotulo || dia.data || "",
          data: dia.data || "",
          episodios: (Array.isArray(eps) ? eps : []).map((ep) => ({
            titulo: ep.titulo || ep.serie || ep.nome || "",
            serie: ep.serie || ep.titulo || ep.nome || "",
            episodio: ep.episodio || ep.epLabel || "",
            horario: ep.horario || ep.hora || "",
            slug: ep.slug || "",
            tipo: ep.tipo || "serie",
            imagem: ep.imagem || ep.capa || "",
            link_detalhe:
              ep.link_detalhe ||
              (ep.slug && String(ep.slug).match(/^\d+$/)
                ? `#/donflix/serie/${encodeURIComponent(ep.slug)}`
                : ep.slug
                  ? `#/cine/serie/${encodeURIComponent(ep.slug)}`
                  : ""),
          })),
        };
      })
      .filter((d) => d.episodios && d.episodios.length > 0);

    limpar(corpo);
    if (!dias.length) {
      corpo.append(el("p", { class: "center" }, "Nenhum episódio agendado nos próximos dias."));
      return page;
    }

    dias.forEach((dia) => {
      const bloco = el("section", { class: "agenda-dia" });
      bloco.append(
        el("div", { class: "agenda-dia-head" }, [
          el("h2", {}, dia.nome || dia.data || "Dia"),
          el("span", { class: "agenda-dia-count" }, `${dia.episodios.length} ep.`),
        ]),
      );
      const lista = el("div", { class: "agenda-lista" });
      dia.episodios.forEach((ep) => {
        const parsed = parseEpLabel(ep.episodio);
        const href = ep.link_detalhe || (ep.slug ? `#/donflix/serie/${encodeURIComponent(ep.slug)}` : "");
        const row = el(
          href ? "a" : "div",
          { class: "agenda-item", href: href || undefined },
          [
            el("div", { class: "agenda-hora" }, ep.horario || "—"),
            el("div", { class: "agenda-info" }, [
              el("p", { class: "agenda-titulo" }, ep.serie || ep.titulo || "Série"),
              el(
                "p",
                { class: "agenda-meta" },
                [ep.episodio, parsed ? `T${parsed.t}E${parsed.e}` : null]
                  .filter(Boolean)
                  .filter((v, i, a) => a.indexOf(v) === i)
                  .join(" · ") || "Episódio",
              ),
            ]),
            el("span", { class: "agenda-chevron", "aria-hidden": "true" }, "›"),
          ],
        );
        lista.append(row);
      });
      bloco.append(lista);
      corpo.append(bloco);
    });
  } catch (e) {
    limpar(corpo);
    corpo.append(el("p", { class: "center" }, "Falha ao carregar a agenda."));
  }
  return page;
}
