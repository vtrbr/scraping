/**
 * playback.js — ponto único para player nativo, progresso e favoritos.
 * Todas as telas devem usar isto em vez de copiar a lógica.
 */

/** Abre o player nativo (Android). Retorna true se abriu. */
export function abrirPlayerNativo(opts = {}) {
  if (!window.AndroidPlayer || typeof window.AndroidPlayer.openPlayer !== "function") {
    return false;
  }
  const fila = JSON.stringify(opts.fila || []);
  const episodios = JSON.stringify(opts.episodios || []);
  const recomendados = JSON.stringify(opts.recomendados || []);
  window.AndroidPlayer.openPlayer(
    opts.categoria || "",
    opts.slug || "",
    opts.titulo || "",
    fila,
    opts.filmeId || opts.slug || "",
    opts.thumb || "",
    opts.tipo || "filme",
    opts.serieCategoria || "",
    opts.serieSlug || "",
    episodios,
    recomendados,
  );
  return true;
}

/** Lista bruta do Continuar assistindo (array). */
export function getContinueList() {
  try {
    const raw = window.AndroidPlayer?.getContinueWatching?.() || "[]";
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    return [];
  }
}

/**
 * Percentual 0–99 a partir de um item de progresso.
 * Aceita percent/progresso, positionMs/durationMs ou positionSeconds/durationSeconds.
 */
export function percentFromItem(item) {
  if (!item) return 0;
  let p = Number(item.percent ?? item.progresso ?? 0);
  if (p > 0) return Math.min(99, Math.round(p));

  let pos = Number(item.positionMs || 0);
  let dur = Number(item.durationMs || 0);
  if ((!pos || !dur) && (item.positionSeconds || item.durationSeconds)) {
    pos = Number(item.positionSeconds || 0) * 1000;
    dur = Number(item.durationSeconds || 0) * 1000;
  }
  if (pos > 0 && dur > 0) {
    return Math.min(99, Math.max(1, Math.round((pos * 100) / dur)));
  }
  return 0;
}

/**
 * Localiza progresso para um título/episódio.
 * Chaves: categoria+slug, filmeId, slug sozinho, ou id NoFlix (filme-{id}).
 * @returns {{ percent: number, positionMs: number, durationMs: number, item: object|null }}
 */
export function lerProgresso({ categoria = "", slug = "", filmeId = "", idtmdb = "" } = {}) {
  const empty = { percent: 0, positionMs: 0, durationMs: 0, item: null };
  try {
    const list = getContinueList();
    const cat = String(categoria || "").trim();
    const s = String(slug || "").trim();
    const id = String(filmeId || "").trim();
    const tid = String(idtmdb || "").trim();

    const hit = list.find((i) => {
      if (cat && s && String(i.categoria || "") === cat && String(i.slug || "") === s) return true;
      if (id && String(i.filmeId || "") === id) return true;
      if (s && String(i.slug || "") === s) return true;
      if (tid) {
        const islug = String(i.slug || "");
        const iid = String(i.filmeId || "");
        if (iid === tid) return true;
        if (islug.includes(`filme-${tid}`) || islug.startsWith(`filme-${tid}`)) return true;
        if (String(i.categoria || "").toLowerCase() === "noflix" && islug.includes(tid)) return true;
      }
      return false;
    });
    if (!hit) return empty;

    const percent = percentFromItem(hit);
    return {
      percent,
      positionMs: Number(hit.positionMs || 0),
      durationMs: Number(hit.durationMs || 0),
      item: hit,
    };
  } catch (_) {
    return empty;
  }
}

/** Atalho: só o número 0–99. */
export function lerPercentual(opts) {
  return lerProgresso(opts).percent;
}

/**
 * Mapa de progresso para listas (favoritos, cards).
 * Chaves: "cat:slug", filmeId, slug, titulo (lowercase).
 */
export function mapaProgresso() {
  const map = {};
  try {
    getContinueList().forEach((item) => {
      const percent = percentFromItem(item);
      if (percent <= 0) return;
      const keys = [
        `${item.categoria || ""}:${item.slug || item.filmeId || ""}`.toLowerCase(),
        String(item.filmeId || "").toLowerCase(),
        String(item.slug || "").toLowerCase(),
        String(item.titulo || "").trim().toLowerCase(),
      ];
      keys.forEach((k) => {
        if (k && k !== ":" && !map[k]) map[k] = percent;
      });
    });
  } catch (_) {}
  return map;
}

/** Lista de favoritos (array). */
export function getFavoritosList() {
  try {
    const resposta = JSON.parse(window.AndroidPlayer?.getFavorites?.() || "{}");
    const lista = resposta.favoritos || resposta.favorites || [];
    return Array.isArray(lista) ? lista : [];
  } catch (_) {
    return [];
  }
}

/** true se o item está nos favoritos. */
export function lerFavorito(filmeId, slug = "", categoria = "") {
  try {
    const lista = getFavoritosList();
    const id = String(filmeId || "").trim();
    const s = String(slug || "").trim().toLowerCase();
    const c = String(categoria || "").trim().toLowerCase();
    return lista.some((item) => {
      const iid = String(item.filmeId || item.contentId || item.id || "").trim();
      const is = String(item.slug || "").trim().toLowerCase();
      const ic = String(item.categoria || "").trim().toLowerCase();
      if (id && iid && id === iid) return true;
      if (s && is && s === is && (!c || !ic || c === ic)) return true;
      return false;
    });
  } catch (_) {
    return false;
  }
}

/**
 * Toggle favorito via bridge nativa.
 * @returns {{ success: boolean, favorito?: boolean, error?: string }}
 */
export function toggleFavorito(filmeId, titulo, thumb, tipo = "filme") {
  try {
    if (!window.AndroidPlayer?.toggleFavorite) {
      return { success: false, error: "Favoritos indisponíveis" };
    }
    const resposta = JSON.parse(
      window.AndroidPlayer.toggleFavorite(
        String(filmeId || ""),
        String(titulo || ""),
        String(thumb || ""),
        String(tipo || "filme"),
      ) || "{}",
    );
    return resposta;
  } catch (e) {
    return { success: false, error: e.message || "Erro ao salvar" };
  }
}
