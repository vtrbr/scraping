/**
 * Tabela canônica de gêneros — Home + Categorias.
 * fontes: megacine (v4) e/ou tedtop (v6)
 */
export const GENEROS_CANONICOS = [
  { slug: "acao", label: "Ação", fontes: ["tedtop", "megacine"], tom: "#c45c4a", ico: "trend" },
  { slug: "aventura", label: "Aventura", fontes: ["megacine"], tom: "#b8733a", ico: "nav" },
  { slug: "animacao", label: "Animação", fontes: ["tedtop", "megacine"], tom: "#4a7ab5", ico: "smile" },
  { slug: "comedia", label: "Comédia", fontes: ["tedtop", "megacine"], tom: "#b89a3a", ico: "smile" },
  { slug: "crime", label: "Crime", fontes: ["megacine"], tom: "#6b4a5a", ico: "shield" },
  { slug: "documentario", label: "Documentário", fontes: ["tedtop", "megacine"], tom: "#3a7a7a", ico: "play" },
  { slug: "drama", label: "Drama", fontes: ["tedtop", "megacine"], tom: "#4a5a8a", ico: "film" },
  { slug: "familia", label: "Família", fontes: ["megacine"], tom: "#3a7a55", ico: "home" },
  { slug: "fantasia", label: "Fantasia", fontes: ["tedtop", "megacine"], tom: "#6a4a9a", ico: "star" },
  { slug: "faroeste", label: "Faroeste", fontes: ["tedtop", "megacine"], tom: "#7a6a4a", ico: "pin" },
  { slug: "ficcao-cientifica", label: "Ficção Científica", fontes: ["tedtop", "megacine"], tom: "#3a6a9a", ico: "rocket" },
  { slug: "guerra", label: "Guerra", fontes: ["megacine"], tom: "#6a4a3a", ico: "alert" },
  { slug: "historia", label: "História", fontes: ["megacine"], tom: "#5a6a4a", ico: "book" },
  { slug: "kids", label: "Kids", fontes: ["megacine"], tom: "#4a8a6a", ico: "smile" },
  { slug: "misterio", label: "Mistério", fontes: ["tedtop", "megacine"], tom: "#3a4a6a", ico: "search" },
  { slug: "musica", label: "Música", fontes: ["megacine"], tom: "#7a4a8a", ico: "music" },
  { slug: "nacionais", label: "Nacionais", fontes: ["tedtop"], tom: "#4a8a4a", ico: "flag" },
  { slug: "policial", label: "Policial", fontes: ["tedtop"], tom: "#4a5a7a", ico: "shield" },
  { slug: "reality", label: "Reality", fontes: ["megacine"], tom: "#7a5a4a", ico: "tv" },
  { slug: "romance", label: "Romance", fontes: ["tedtop", "megacine"], tom: "#8a4a6a", ico: "heart" },
  { slug: "suspense", label: "Suspense", fontes: ["tedtop"], tom: "#5a4a6a", ico: "alert" },
  { slug: "terror", label: "Terror", fontes: ["tedtop", "megacine"], tom: "#8a3a3a", ico: "alert" },
];

/** Subconjunto para fileiras da Home (ordem de exibição). */
export const GENEROS_HOME = [
  "acao",
  "animacao",
  "aventura",
  "comedia",
  "drama",
  "ficcao-cientifica",
  "romance",
  "suspense",
  "terror",
  "fantasia",
  "misterio",
  "familia",
];
